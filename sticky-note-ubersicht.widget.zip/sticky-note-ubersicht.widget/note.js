command:"",
refreshFrequency: false,
render: function(){

	$('head').append('<link rel="stylesheet" href="css/StickyNoteDemo.css"><script src="js/jquery.postitall.js"></script><script src="js/sticky.js"></script>');
	return "";
	
},
update: function (){
},
style: "        \n\
  top: 100px     \n\
  left: 500px     \n\
  color: #fff     \n\
  font-family: Helvetica Neue     \n\
  "
	

