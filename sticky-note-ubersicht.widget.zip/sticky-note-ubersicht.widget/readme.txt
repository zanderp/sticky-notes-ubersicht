Installation:
Copy the files to your Ubersicht Widget Folder.
Usage:
This widget requires remaping your interraction key. To properly use the plugin go to Ubersicht menu ->Preferences-> Interraction Shortcut - select the third in the list(Alt Key).
Press Alt key to interract with the widget and to add text.